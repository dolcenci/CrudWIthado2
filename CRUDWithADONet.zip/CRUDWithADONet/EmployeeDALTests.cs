﻿using Moq;
using CRUDWithADONet.DAL;
using CRUDWithADONet.Models;
using Microsoft.Data.SqlClient;
using System.Data;
using Xunit;

namespace CRUDWithADONet.Tests.DAL
{
    public class EmployeeDALTests
    {
        private readonly Mock<Employee_DAL> _mockDal;

        public EmployeeDALTests()
        {
            _mockDal = new Mock<Employee_DAL>();
        }

        [Fact]
        public void GetAll_ReturnsListOfEmployees()
        {
            // Arrange
            var employees = new List<Employee>
            {
                new Employee { ID = 1, FirstName = "John", LastName = "Doe", Email = "john@example.com", Salary = 50000 },
                new Employee { ID = 2, FirstName = "Jane", LastName = "Smith", Email = "jane@example.com", Salary = 60000 }
            };
            _mockDal.Setup(dal => dal.GetAll()).Returns(employees);

            // Act
            var result = _mockDal.Object.GetAll();

            // Assert
            Assert.NotNull(result);
            Assert.Equal(2, result.Count);
            Assert.Equal("John", result[0].FirstName);
            Assert.Equal("Jane", result[1].FirstName);
        }

        [Fact]
        public void GetById_ReturnsCorrectEmployee()
        {
            // Arrange
            var employee = new Employee { ID = 1, FirstName = "John", LastName = "Doe" };
            _mockDal.Setup(dal => dal.GetById(1)).Returns(employee);

            // Act
            var result = _mockDal.Object.GetById(1);

            // Assert
            Assert.NotNull(result);
            Assert.Equal(1, result.ID);
            Assert.Equal("John", result.FirstName);
        }

        [Fact]
        public void Create_ReturnsTrue_WhenEmployeeIsCreated()
        {
            // Arrange
            var employee = new Employee
            {
                FirstName = "New",
                LastName = "Employee",
                Email = "new@example.com",
                DateOfBirth = new System.DateTime(1990, 1, 1),
                Salary = 45000
            };
            _mockDal.Setup(dal => dal.Create(employee)).Returns(true);

            // Act
            var result = _mockDal.Object.Create(employee);

            // Assert
            Assert.True(result);
        }

        [Fact]
        public void Update_ReturnsTrue_WhenEmployeeIsUpdated()
        {
            // Arrange
            var employee = new Employee
            {
                ID = 1,
                FirstName = "Updated",
                LastName = "Name",
                Email = "updated@example.com",
                DateOfBirth = new System.DateTime(1990, 1, 1),
                Salary = 55000
            };
            _mockDal.Setup(dal => dal.Update(employee)).Returns(true);

            // Act
            var result = _mockDal.Object.Update(employee);

            // Assert
            Assert.True(result);
        }

        [Fact]
        public void Delete_ReturnsTrue_WhenEmployeeIsDeleted()
        {
            // Arrange
            _mockDal.Setup(dal => dal.Delete(1)).Returns(true);

            // Act
            var result = _mockDal.Object.Delete(1);

            // Assert
            Assert.True(result);
        }
    }
}