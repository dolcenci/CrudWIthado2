﻿using CRUDWithADONet.DAL;
using CRUDWithADONet.Models;
using Microsoft.AspNetCore.Mvc;

namespace CRUDWithADONet.Controllers
{
    public class ReportController : Controller
    {
        private readonly Employee_DAL _employeeDal;

        public ReportController(Employee_DAL employeeDal)
        {
            _employeeDal = employeeDal;
        }

        // Payment Reports Summary
        public IActionResult PaymentSummary()
        {
            try
            {
                var allEmployees = _employeeDal.GetAll();
                var approvedEmployees = allEmployees.Where(e => e.Status == "Approved").ToList();

                var report = new PaymentReportSummary
                {
                    TotalApprovedClaims = approvedEmployees.Count,
                    TotalHours = approvedEmployees.Sum(e => e.HoursWorked ?? 0),
                    TotalEarnings = approvedEmployees.Sum(e => e.TotalEarnings),
                    AverageHourlyRate = approvedEmployees.Any() ? approvedEmployees.Average(e => e.HourlyRate ?? 0) : 0,
                    ApprovedEmployees = approvedEmployees,
                    ReportDate = DateTime.Now
                };

                return View(report);
            }
            catch (Exception ex)
            {
                TempData["errorMessage"] = $"Error generating report: {ex.Message}";
                return View(new PaymentReportSummary());
            }
        }

        // Export to PDF (simulated)
        public IActionResult ExportToPdf()
        {
            TempData["successMessage"] = "Report exported to PDF successfully! (Simulated)";
            return RedirectToAction("PaymentSummary");
        }

        // Export to Excel (simulated)
        public IActionResult ExportToExcel()
        {
            TempData["successMessage"] = "Report exported to Excel successfully! (Simulated)";
            return RedirectToAction("PaymentSummary");
        }
    }
}