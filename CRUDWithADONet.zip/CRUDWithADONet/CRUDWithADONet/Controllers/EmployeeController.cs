﻿using CRUDWithADONet.DAL;
using CRUDWithADONet.Models;
using Microsoft.AspNetCore.Mvc;

namespace CRUDWithADONet.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly Employee_DAL _dal;

        public EmployeeController(Employee_DAL dal)
        {
            _dal = dal;
        }

        // Automated approval criteria
        private (string decision, string reason) CheckAutomatedApproval(Employee employee)
        {
            // Criteria 1: Salary range
            if (employee.Salary < 30000)
            {
                return ("Rejected", "Salary below minimum threshold ($30,000)");
            }

            if (employee.Salary > 150000)
            {
                return ("Rejected", "Salary above maximum threshold ($150,000)");
            }

            // Criteria 2: Hourly rate validation
            if (employee.HourlyRate.HasValue)
            {
                if (employee.HourlyRate < 15)
                {
                    return ("Rejected", "Hourly rate below minimum ($15/hour)");
                }

                if (employee.HourlyRate > 100)
                {
                    return ("Rejected", "Hourly rate above maximum ($100/hour)");
                }
            }

            // Criteria 3: Hours worked validation
            if (employee.HoursWorked.HasValue)
            {
                if (employee.HoursWorked < 10)
                {
                    return ("Rejected", "Hours worked too low (minimum 10 hours)");
                }

                if (employee.HoursWorked > 60)
                {
                    return ("Rejected", "Hours worked exceeds maximum (60 hours per week)");
                }
            }

            // Criteria 4: Age validation (must be at least 18)
            var age = DateTime.Now.Year - employee.DateOfBirth.Year;
            if (DateTime.Now.DayOfYear < employee.DateOfBirth.DayOfYear)
                age--;

            if (age < 18)
            {
                return ("Rejected", "Employee must be at least 18 years old");
            }

            // Criteria 5: Email domain validation
            if (!employee.Email.EndsWith("@company.com") && !employee.Email.EndsWith("@partner.com"))
            {
                return ("Rejected", "Invalid email domain. Must be @company.com or @partner.com");
            }

            // All criteria passed
            return ("Approved", "All automated criteria satisfied");
        }

        [HttpGet]
        public IActionResult Index()
        {
            List<Employee> employees = new List<Employee>();
            try
            {
                employees = _dal.GetAll();
            }
            catch (Exception ex)
            {
                TempData["errorMessage"] = ex.Message;
            }
            return View(employees);
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(Employee employee)
        {
            try
            {
                // Clear ModelState for ALL optional fields
                ModelState.Remove("Notes");
                ModelState.Remove("HourlyRate");
                ModelState.Remove("HoursWorked");
                ModelState.Remove("DocumentPath");
                ModelState.Remove("DocumentFile");
                ModelState.Remove("SelectedFileName");
                ModelState.Remove("AutomatedDecision");
                ModelState.Remove("DecisionReason");
                ModelState.Remove("IsOverridden");
                ModelState.Remove("OverriddenBy");
                ModelState.Remove("OverrideReason");

                // Remove validation for the new optional fields
                ModelState.Remove("PhoneNumber");
                ModelState.Remove("Address");
                ModelState.Remove("Department");
                ModelState.Remove("EmergencyContact");
                ModelState.Remove("BankDetails");

                if (ModelState.IsValid)
                {
                    // Run automated approval process BEFORE creating the employee
                    var (decision, reason) = CheckAutomatedApproval(employee);

                    // Set the automated decision results
                    employee.AutomatedDecision = decision;
                    employee.DecisionReason = reason;
                    employee.Status = decision; // Set the main status to the automated decision

                    // Handle fake document
                    if (!string.IsNullOrEmpty(employee.SelectedFileName))
                    {
                        employee.DocumentPath = $"/documents/{employee.FirstName}_{employee.LastName}_{employee.SelectedFileName}";
                    }
                    else
                    {
                        employee.DocumentPath = $"/documents/{employee.FirstName}_{employee.LastName}_employment_contract.pdf";
                    }

                    // Create employee with the automated decision
                    bool result = _dal.Create(employee);
                    if (result)
                    {
                        string message = decision == "Approved"
                            ? $"Employee created successfully! ✅ Automatically APPROVED - {reason}"
                            : $"Employee created successfully! ❌ Automatically REJECTED - {reason}";

                        TempData["successMessage"] = message;
                        return RedirectToAction("Index");
                    }
                    else
                    {
                        TempData["errorMessage"] = "Failed to create employee in database.";
                    }
                }
                else
                {
                    var errors = ModelState
                        .Where(x => x.Value.Errors.Count > 0)
                        .Select(x => $"{x.Key}: {string.Join(", ", x.Value.Errors.Select(e => e.ErrorMessage))}");

                    TempData["errorMessage"] = $"Please fix the following errors: {string.Join("; ", errors)}";
                }
            }
            catch (Exception ex)
            {
                TempData["errorMessage"] = $"Error: {ex.Message}";
            }
            return View(employee);
        }

        [HttpGet]
        public IActionResult OverrideStatus(int id)
        {
            try
            {
                Employee employee = _dal.GetById(id);
                if (employee != null)
                {
                    var model = new StatusOverride
                    {
                        EmployeeId = employee.ID,
                        NewStatus = employee.Status
                    };
                    return View(model);
                }
                TempData["errorMessage"] = "Employee not found.";
            }
            catch (Exception ex)
            {
                TempData["errorMessage"] = ex.Message;
            }
            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult OverrideStatus(StatusOverride model)
        {
            try
            {
                // Get current user role (simulated)
                string userRole = "Manager"; // Default for demo

                bool result = _dal.OverrideStatus(model.EmployeeId, model.NewStatus, model.Reason, userRole);
                if (result)
                {
                    TempData["successMessage"] = $"Status successfully overridden to {model.NewStatus}";
                }
                else
                {
                    TempData["errorMessage"] = "Failed to override status.";
                }
            }
            catch (Exception ex)
            {
                TempData["errorMessage"] = $"Error: {ex.Message}";
            }
            return RedirectToAction("Index");
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            try
            {
                Employee employee = _dal.GetById(id);
                if (employee != null)
                {
                    return View(employee);
                }
                TempData["errorMessage"] = "Employee not found.";
            }
            catch (Exception ex)
            {
                TempData["errorMessage"] = ex.Message;
            }
            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult Edit(Employee employee)
        {
            try
            {
                // Clear ModelState for ALL optional fields
                ModelState.Remove("Notes");
                ModelState.Remove("HourlyRate");
                ModelState.Remove("HoursWorked");
                ModelState.Remove("DocumentPath");
                ModelState.Remove("DocumentFile");
                ModelState.Remove("SelectedFileName");
                ModelState.Remove("AutomatedDecision");
                ModelState.Remove("DecisionReason");
                ModelState.Remove("IsOverridden");
                ModelState.Remove("OverriddenBy");
                ModelState.Remove("OverrideReason");

                // Remove validation for the new optional fields
                ModelState.Remove("PhoneNumber");
                ModelState.Remove("Address");
                ModelState.Remove("Department");
                ModelState.Remove("EmergencyContact");
                ModelState.Remove("BankDetails");

                if (ModelState.IsValid)
                {
                    // Fake document handling for edit
                    if (!string.IsNullOrEmpty(employee.SelectedFileName))
                    {
                        employee.DocumentPath = $"/documents/{employee.FirstName}_{employee.LastName}_{employee.SelectedFileName}";
                    }

                    bool result = _dal.Update(employee);
                    if (result)
                    {
                        TempData["successMessage"] = "Employee updated successfully!";
                        return RedirectToAction("Index");
                    }
                    else    
                    {
                        TempData["errorMessage"] = "Failed to update employee.";
                    }
                }
                else
                {
                    var errors = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage);
                    TempData["errorMessage"] = "Please fix the following errors: " + string.Join(", ", errors);
                }
            }
            catch (Exception ex)
            {
                TempData["errorMessage"] = ex.Message;
            }
            return View(employee);
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            try
            {
                Employee employee = _dal.GetById(id);
                if (employee != null)
                {
                    return View(employee);
                }
                TempData["errorMessage"] = "Employee not found.";
            }
            catch (Exception ex)
            {
                TempData["errorMessage"] = ex.Message;
            }
            return RedirectToAction("Index");
        }

        [HttpPost]
        [ActionName("Delete")]
        public IActionResult DeleteConfirmed(int id)
        {
            try
            {
                bool result = _dal.Delete(id);
                if (result)
                {
                    TempData["successMessage"] = "Employee deleted successfully!";
                }
                else
                {
                    TempData["errorMessage"] = "Failed to delete employee.";
                }
            }
            catch (Exception ex)
            {
                TempData["errorMessage"] = ex.Message;
            }
            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult Approve(int id)
        {
            try
            {
                bool result = _dal.UpdateStatus(id, "Approved");
                if (result)
                {
                    TempData["successMessage"] = "Employee approved successfully!";
                }
                else
                {
                    TempData["errorMessage"] = "Failed to approve employee.";
                }
            }
            catch (Exception ex)
            {
                TempData["errorMessage"] = $"Error: {ex.Message}";
            }
            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult Reject(int id)
        {
            try
            {
                bool result = _dal.UpdateStatus(id, "Rejected");
                if (result)
                {
                    TempData["successMessage"] = "Employee rejected successfully!";
                }
                else
                {
                    TempData["errorMessage"] = "Failed to reject employee.";
                }
            }
            catch (Exception ex)
            {
                TempData["errorMessage"] = $"Error: {ex.Message}";
            }
            return RedirectToAction("Index");
        }
    }
}