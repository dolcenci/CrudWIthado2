using Microsoft.AspNetCore.Mvc;

namespace CRUDWithADONet.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        // New actions for role-based access
        public IActionResult Employee()
        {
            return RedirectToAction("Create", "Employee");
        }

        public IActionResult Manager()
        {
            return RedirectToAction("Index", "Employee");
        }

        public IActionResult Coordinator()
        {
            return RedirectToAction("Index", "Employee");
        }
    }
}