﻿using CRUDWithADONet.Models;
using Microsoft.Data.SqlClient;
using System.Data;

namespace CRUDWithADONet.DAL
{
    public class Invoice_DAL
    {
        SqlConnection _connection = null;
        SqlCommand _command = null;

        private string GetConnectionString()
        {
            var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json");
            var configuration = builder.Build();
            return configuration.GetConnectionString("DefaultConnection");
        }

        public int GenerateInvoices(string period)
        {
            using (_connection = new SqlConnection(GetConnectionString()))
            {
                _command = _connection.CreateCommand();
                _command.CommandType = CommandType.StoredProcedure;
                _command.CommandText = "[DBO].[usp_Generate_Invoices]";
                _command.Parameters.AddWithValue("@Period", period);

                _connection.Open();
                var result = _command.ExecuteScalar();
                _connection.Close();

                return result != null ? Convert.ToInt32(result) : 0;
            }
        }

        public List<Invoice> GetInvoices()
        {
            List<Invoice> invoices = new List<Invoice>();
            using (_connection = new SqlConnection(GetConnectionString()))
            {
                _command = _connection.CreateCommand();
                _command.CommandType = CommandType.StoredProcedure;
                _command.CommandText = "[DBO].[usp_Get_Invoices]";

                _connection.Open();
                SqlDataReader dr = _command.ExecuteReader();
                while (dr.Read())
                {
                    Invoice invoice = new Invoice();
                    invoice.Id = Convert.ToInt32(dr["Id"]);
                    invoice.InvoiceNumber = dr["InvoiceNumber"].ToString();
                    invoice.EmployeeName = dr["EmployeeName"].ToString();
                    invoice.EmployeeId = Convert.ToInt32(dr["EmployeeId"]);
                    invoice.Period = dr["Period"].ToString();
                    invoice.TotalHours = Convert.ToDecimal(dr["TotalHours"]);
                    invoice.HourlyRate = Convert.ToDecimal(dr["HourlyRate"]);
                    invoice.TotalAmount = Convert.ToDecimal(dr["TotalAmount"]);
                    invoice.GeneratedDate = Convert.ToDateTime(dr["GeneratedDate"]);
                    invoice.Status = dr["Status"].ToString();
                    invoices.Add(invoice);
                }
                _connection.Close();
            }
            return invoices;
        }

        public int GeneratePaymentReport(string period, string reportType)
        {
            using (_connection = new SqlConnection(GetConnectionString()))
            {
                _command = _connection.CreateCommand();
                _command.CommandType = CommandType.StoredProcedure;
                _command.CommandText = "[DBO].[usp_Generate_Payment_Report]";
                _command.Parameters.AddWithValue("@Period", period);
                _command.Parameters.AddWithValue("@ReportType", reportType);

                _connection.Open();
                var result = _command.ExecuteScalar();
                _connection.Close();

                return result != null ? Convert.ToInt32(result) : 0;
            }
        }

        public List<PaymentReport> GetPaymentReports()
        {
            List<PaymentReport> reports = new List<PaymentReport>();
            using (_connection = new SqlConnection(GetConnectionString()))
            {
                _command = _connection.CreateCommand();
                _command.CommandType = CommandType.StoredProcedure;
                _command.CommandText = "[DBO].[usp_Get_Payment_Reports]";

                _connection.Open();
                SqlDataReader dr = _command.ExecuteReader();
                while (dr.Read())
                {
                    PaymentReport report = new PaymentReport();
                    report.Id = Convert.ToInt32(dr["Id"]);
                    report.ReportPeriod = dr["ReportPeriod"].ToString();
                    report.TotalEmployees = Convert.ToInt32(dr["TotalEmployees"]);
                    report.TotalHours = Convert.ToDecimal(dr["TotalHours"]);
                    report.TotalAmount = Convert.ToDecimal(dr["TotalAmount"]);
                    report.GeneratedDate = Convert.ToDateTime(dr["GeneratedDate"]);
                    report.ReportType = dr["ReportType"].ToString();
                    reports.Add(report);
                }
                _connection.Close();
            }
            return reports;
        }

        public bool UpdateLecturerInfo(LecturerUpdate lecturer)
        {
            using (_connection = new SqlConnection(GetConnectionString()))
            {
                _command = _connection.CreateCommand();
                _command.CommandType = CommandType.StoredProcedure;
                _command.CommandText = "[DBO].[usp_Update_Lecturer_Info]";

                _command.Parameters.AddWithValue("@Id", lecturer.EmployeeId);
                _command.Parameters.AddWithValue("@FirstName", lecturer.FirstName);
                _command.Parameters.AddWithValue("@LastName", lecturer.LastName);
                _command.Parameters.AddWithValue("@Email", lecturer.Email);
                _command.Parameters.AddWithValue("@PhoneNumber", string.IsNullOrEmpty(lecturer.PhoneNumber) ? DBNull.Value : lecturer.PhoneNumber);
                _command.Parameters.AddWithValue("@Address", string.IsNullOrEmpty(lecturer.Address) ? DBNull.Value : lecturer.Address);
                _command.Parameters.AddWithValue("@Department", string.IsNullOrEmpty(lecturer.Department) ? DBNull.Value : lecturer.Department);
                _command.Parameters.AddWithValue("@EmergencyContact", string.IsNullOrEmpty(lecturer.EmergencyContact) ? DBNull.Value : lecturer.EmergencyContact);
                _command.Parameters.AddWithValue("@BankDetails", string.IsNullOrEmpty(lecturer.BankDetails) ? DBNull.Value : lecturer.BankDetails);

                _connection.Open();
                int result = _command.ExecuteNonQuery();
                _connection.Close();

                return result > 0;
            }
        }
    }
}






/*namespace CRUDWithADONet.DAL
{
    public class Invoice_DAL
    {
    }
}*/
