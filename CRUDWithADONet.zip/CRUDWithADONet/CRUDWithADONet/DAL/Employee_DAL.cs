﻿using System.Data;
using Microsoft.Data.SqlClient;
using CRUDWithADONet.Models;

namespace CRUDWithADONet.DAL
{
    public class Employee_DAL
    {
        SqlConnection _connection = null;
        SqlCommand _command = null;

        private string GetConnectionString()
        {
            var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json");
            var configuration = builder.Build();
            return configuration.GetConnectionString("DefaultConnection");
        }

        public bool Create(Employee employee)
        {
            try
            {
                using (_connection = new SqlConnection(GetConnectionString()))
                {
                    _command = _connection.CreateCommand();
                    _command.CommandType = CommandType.StoredProcedure;
                    _command.CommandText = "[DBO].[usp_Insert_Employee]";

                    _command.Parameters.AddWithValue("@FirstName", employee.FirstName);
                    _command.Parameters.AddWithValue("@LastName", employee.LastName);
                    _command.Parameters.AddWithValue("@DateOfBirth", employee.DateOfBirth);
                    _command.Parameters.AddWithValue("@Email", employee.Email);
                    _command.Parameters.AddWithValue("@Salary", employee.Salary);
                    _command.Parameters.AddWithValue("@HourlyRate", employee.HourlyRate.HasValue ? (object)employee.HourlyRate.Value : DBNull.Value);
                    _command.Parameters.AddWithValue("@HoursWorked", employee.HoursWorked.HasValue ? (object)employee.HoursWorked.Value : DBNull.Value);
                    _command.Parameters.AddWithValue("@Notes", string.IsNullOrEmpty(employee.Notes) ? DBNull.Value : employee.Notes);
                    _command.Parameters.AddWithValue("@Status", employee.Status);
                    _command.Parameters.AddWithValue("@AutomatedDecision", string.IsNullOrEmpty(employee.AutomatedDecision) ? DBNull.Value : employee.AutomatedDecision);
                    _command.Parameters.AddWithValue("@DecisionReason", string.IsNullOrEmpty(employee.DecisionReason) ? DBNull.Value : employee.DecisionReason);

                    _connection.Open();
                    int result = _command.ExecuteNonQuery();
                    _connection.Close();

                    return result > 0;
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Database Error in Create: {ex.Message}");
                throw;
            }
        }

        public bool UpdateStatus(int id, string status)
        {
            using (_connection = new SqlConnection(GetConnectionString()))
            {
                _command = _connection.CreateCommand();
                _command.CommandType = CommandType.StoredProcedure;
                _command.CommandText = "[DBO].[usp_Update_Employee_Status]";

                _command.Parameters.AddWithValue("@Id", id);
                _command.Parameters.AddWithValue("@Status", status);

                _connection.Open();
                int result = _command.ExecuteNonQuery();
                _connection.Close();

                return result > 0;
            }
        }

        public bool UpdateAutomatedDecision(int id, string decision, string reason)
        {
            using (_connection = new SqlConnection(GetConnectionString()))
            {
                _command = _connection.CreateCommand();
                _command.CommandType = CommandType.StoredProcedure;
                _command.CommandText = "[DBO].[usp_Update_Automated_Decision]";

                _command.Parameters.AddWithValue("@Id", id);
                _command.Parameters.AddWithValue("@AutomatedDecision", decision);
                _command.Parameters.AddWithValue("@DecisionReason", reason);
                _command.Parameters.AddWithValue("@Status", decision);

                _connection.Open();
                int result = _command.ExecuteNonQuery();
                _connection.Close();

                return result > 0;
            }
        }

        public bool OverrideStatus(int id, string newStatus, string reason, string overriddenBy)
        {
            using (_connection = new SqlConnection(GetConnectionString()))
            {
                _command = _connection.CreateCommand();
                _command.CommandType = CommandType.StoredProcedure;
                _command.CommandText = "[DBO].[usp_Override_Employee_Status]";

                _command.Parameters.AddWithValue("@Id", id);
                _command.Parameters.AddWithValue("@Status", newStatus);
                _command.Parameters.AddWithValue("@IsOverridden", true);
                _command.Parameters.AddWithValue("@OverriddenBy", overriddenBy);
                _command.Parameters.AddWithValue("@OverrideReason", reason);

                _connection.Open();
                int result = _command.ExecuteNonQuery();
                _connection.Close();

                return result > 0;
            }
        }

        public List<Employee> GetAll()
        {
            List<Employee> employeeList = new List<Employee>();
            using (_connection = new SqlConnection(GetConnectionString()))
            {
                _command = _connection.CreateCommand();
                _command.CommandType = CommandType.StoredProcedure;
                _command.CommandText = "[DBO].[usp_Get_Employees]";

                _connection.Open();
                SqlDataReader dr = _command.ExecuteReader();
                while (dr.Read())
                {
                    Employee employee = new Employee();
                    employee.ID = Convert.ToInt32(dr["Id"]);
                    employee.FirstName = dr["FirstName"].ToString();
                    employee.LastName = dr["LastName"].ToString();
                    employee.DateOfBirth = Convert.ToDateTime(dr["DateOfBirth"]);
                    employee.Email = dr["Email"].ToString();
                    employee.Salary = Convert.ToDouble(dr["Salary"]);
                    employee.HourlyRate = dr["HourlyRate"] != DBNull.Value ? Convert.ToDecimal(dr["HourlyRate"]) : null;
                    employee.HoursWorked = dr["HoursWorked"] != DBNull.Value ? Convert.ToDecimal(dr["HoursWorked"]) : null;
                    employee.Notes = dr["Notes"] != DBNull.Value ? dr["Notes"].ToString() : null;
                    employee.Status = dr["Status"].ToString();

                    // Automated decision fields
                    employee.AutomatedDecision = dr["AutomatedDecision"] != DBNull.Value ? dr["AutomatedDecision"].ToString() : null;
                    employee.DecisionReason = dr["DecisionReason"] != DBNull.Value ? dr["DecisionReason"].ToString() : null;
                    employee.IsOverridden = dr["IsOverridden"] != DBNull.Value ? Convert.ToBoolean(dr["IsOverridden"]) : false;
                    employee.OverriddenBy = dr["OverriddenBy"] != DBNull.Value ? dr["OverriddenBy"].ToString() : null;
                    employee.OverrideReason = dr["OverrideReason"] != DBNull.Value ? dr["OverrideReason"].ToString() : null;

                    // Lecturer management fields
                    employee.PhoneNumber = dr["PhoneNumber"] != DBNull.Value ? dr["PhoneNumber"].ToString() : null;
                    employee.Address = dr["Address"] != DBNull.Value ? dr["Address"].ToString() : null;
                    employee.Department = dr["Department"] != DBNull.Value ? dr["Department"].ToString() : null;
                    employee.EmergencyContact = dr["EmergencyContact"] != DBNull.Value ? dr["EmergencyContact"].ToString() : null;
                    employee.BankDetails = dr["BankDetails"] != DBNull.Value ? dr["BankDetails"].ToString() : null;

                    employeeList.Add(employee);
                }
                _connection.Close();
            }
            return employeeList;
        }

        public Employee GetById(int id)
        {
            Employee employee = null;
            using (_connection = new SqlConnection(GetConnectionString()))
            {
                _command = _connection.CreateCommand();
                _command.CommandType = CommandType.StoredProcedure;
                _command.CommandText = "[DBO].[usp_Get_Employee_By_Id]";
                _command.Parameters.AddWithValue("@Id", id);

                _connection.Open();
                SqlDataReader dr = _command.ExecuteReader();

                if (dr.Read())
                {
                    employee = new Employee();
                    employee.ID = Convert.ToInt32(dr["Id"]);
                    employee.FirstName = dr["FirstName"].ToString();
                    employee.LastName = dr["LastName"].ToString();
                    employee.DateOfBirth = Convert.ToDateTime(dr["DateOfBirth"]);
                    employee.Email = dr["Email"].ToString();
                    employee.Salary = Convert.ToDouble(dr["Salary"]);
                    employee.HourlyRate = dr["HourlyRate"] != DBNull.Value ? Convert.ToDecimal(dr["HourlyRate"]) : null;
                    employee.HoursWorked = dr["HoursWorked"] != DBNull.Value ? Convert.ToDecimal(dr["HoursWorked"]) : null;
                    employee.Notes = dr["Notes"] != DBNull.Value ? dr["Notes"].ToString() : null;
                    employee.Status = dr["Status"].ToString();

                    // Automated decision fields
                    employee.AutomatedDecision = dr["AutomatedDecision"] != DBNull.Value ? dr["AutomatedDecision"].ToString() : null;
                    employee.DecisionReason = dr["DecisionReason"] != DBNull.Value ? dr["DecisionReason"].ToString() : null;
                    employee.IsOverridden = dr["IsOverridden"] != DBNull.Value ? Convert.ToBoolean(dr["IsOverridden"]) : false;
                    employee.OverriddenBy = dr["OverriddenBy"] != DBNull.Value ? dr["OverriddenBy"].ToString() : null;
                    employee.OverrideReason = dr["OverrideReason"] != DBNull.Value ? dr["OverrideReason"].ToString() : null;

                    // Lecturer management fields
                    employee.PhoneNumber = dr["PhoneNumber"] != DBNull.Value ? dr["PhoneNumber"].ToString() : null;
                    employee.Address = dr["Address"] != DBNull.Value ? dr["Address"].ToString() : null;
                    employee.Department = dr["Department"] != DBNull.Value ? dr["Department"].ToString() : null;
                    employee.EmergencyContact = dr["EmergencyContact"] != DBNull.Value ? dr["EmergencyContact"].ToString() : null;
                    employee.BankDetails = dr["BankDetails"] != DBNull.Value ? dr["BankDetails"].ToString() : null;
                }
                _connection.Close();
            }
            return employee;
        }

        public bool Update(Employee employee)
        {
            using (_connection = new SqlConnection(GetConnectionString()))
            {
                _command = _connection.CreateCommand();
                _command.CommandType = CommandType.StoredProcedure;
                _command.CommandText = "[DBO].[usp_Update_Employee]";

                _command.Parameters.AddWithValue("@Id", employee.ID);
                _command.Parameters.AddWithValue("@FirstName", employee.FirstName);
                _command.Parameters.AddWithValue("@LastName", employee.LastName);
                _command.Parameters.AddWithValue("@DateOfBirth", employee.DateOfBirth);
                _command.Parameters.AddWithValue("@Email", employee.Email);
                _command.Parameters.AddWithValue("@Salary", employee.Salary);
                _command.Parameters.AddWithValue("@HourlyRate", employee.HourlyRate.HasValue ? (object)employee.HourlyRate.Value : DBNull.Value);
                _command.Parameters.AddWithValue("@HoursWorked", employee.HoursWorked.HasValue ? (object)employee.HoursWorked.Value : DBNull.Value);
                _command.Parameters.AddWithValue("@Notes", string.IsNullOrEmpty(employee.Notes) ? DBNull.Value : employee.Notes);
                _command.Parameters.AddWithValue("@Status", string.IsNullOrEmpty(employee.Status) ? DBNull.Value : employee.Status);
                _command.Parameters.AddWithValue("@AutomatedDecision", string.IsNullOrEmpty(employee.AutomatedDecision) ? DBNull.Value : employee.AutomatedDecision);
                _command.Parameters.AddWithValue("@DecisionReason", string.IsNullOrEmpty(employee.DecisionReason) ? DBNull.Value : employee.DecisionReason);

                _connection.Open();
                int result = _command.ExecuteNonQuery();
                _connection.Close();

                return result > 0;
            }
        }

        public bool Delete(int id)
        {
            using (_connection = new SqlConnection(GetConnectionString()))
            {
                _command = _connection.CreateCommand();
                _command.CommandType = CommandType.StoredProcedure;
                _command.CommandText = "[DBO].[usp_Delete_Employee]";
                _command.Parameters.AddWithValue("@Id", id);

                _connection.Open();
                int result = _command.ExecuteNonQuery();
                _connection.Close();

                return result > 0;
            }
        }
    }
}