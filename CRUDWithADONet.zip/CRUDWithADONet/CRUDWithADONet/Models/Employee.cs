﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace CRUDWithADONet.Models
{
    public class Employee
    {
        [Key]
        public int ID { get; set; }

        [DisplayName("First Name")]
        [Required(ErrorMessage = "First Name is required")]
        public string FirstName { get; set; }

        [DisplayName("Last Name")]
        [Required(ErrorMessage = "Last Name is required")]
        public string LastName { get; set; }

        [DisplayName("Date Of Birth")]
        [Required(ErrorMessage = "Date of Birth is required")]
        [DataType(DataType.Date)]
        public DateTime DateOfBirth { get; set; }

        [DisplayName("Email")]
        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Invalid email address")]
        public string Email { get; set; }

        [DisplayName("Salary")]
        [Range(0, double.MaxValue, ErrorMessage = "Salary must be a positive number")]
        public double Salary { get; set; }

        [DisplayName("Hourly Rate")]
        [Range(0, 1000, ErrorMessage = "Hourly rate must be between 0 and 1000")]
        public decimal? HourlyRate { get; set; }

        [DisplayName("Hours Worked")]
        [Range(0, 168, ErrorMessage = "Hours worked must be between 0 and 168")]
        public decimal? HoursWorked { get; set; }

        [DisplayName("Notes")]
        [StringLength(1000, ErrorMessage = "Notes cannot exceed 1000 characters")]
        public string Notes { get; set; }

        [DisplayName("Status")]
        public string Status { get; set; } = "Pending";

        // Automated approval tracking
        [DisplayName("Automated Decision")]
        public string AutomatedDecision { get; set; }

        [DisplayName("Decision Reason")]
        public string DecisionReason { get; set; }

        [DisplayName("Is Overridden")]
        public bool IsOverridden { get; set; } = false;

        [DisplayName("Overridden By")]
        public string OverriddenBy { get; set; }

        [DisplayName("Override Reason")]
        public string OverrideReason { get; set; }

        // Fake document properties
        [DisplayName("Document Path")]
        public string DocumentPath { get; set; }

        [DisplayName("Upload Document")]
        public IFormFile DocumentFile { get; set; }

        [DisplayName("Selected File Name")]
        public string SelectedFileName { get; set; }

        // Additional fields for lecturer management - MAKE THESE OPTIONAL
        [DisplayName("Phone Number")]
        public string PhoneNumber { get; set; }

        [DisplayName("Address")]
        public string Address { get; set; }

        [DisplayName("Department")]
        public string Department { get; set; }

        [DisplayName("Emergency Contact")]
        public string EmergencyContact { get; set; }

        [DisplayName("Bank Details")]
        public string BankDetails { get; set; }

        // Calculated properties
        [DisplayName("Total Earnings")]
        public decimal TotalEarnings
        {
            get
            {
                return (HourlyRate ?? 0) * (HoursWorked ?? 0);
            }
        }

        [DisplayName("Full Name")]
        public string FullName
        {
            get { return FirstName + " " + LastName; }
        }
    }

    // Model for override actions
    public class StatusOverride
    {
        public int EmployeeId { get; set; }
        public string NewStatus { get; set; }
        public string Reason { get; set; }
        public string OverriddenBy { get; set; }
    }

    // Model for lecturer updates
    public class LecturerUpdate
    {
        public int EmployeeId { get; set; }

        [DisplayName("First Name")]
        [Required(ErrorMessage = "First Name  required")]
        public string FirstName { get; set; }

        [DisplayName("Last Name")]
        [Required(ErrorMessage = "Last Name is required")]
        public string LastName { get; set; }

        [DisplayName("Email")]
        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Invalid email address")]
        public string Email { get; set; }

        [DisplayName("Phone Number")]
        public string PhoneNumber { get; set; }

        [DisplayName("Address")]
        public string Address { get; set; }

        [DisplayName("Department")]
        public string Department { get; set; }

        [DisplayName("Emergency Contact")]
        public string EmergencyContact { get; set; }

        [DisplayName("Bank Details")]
        public string BankDetails { get; set; }
    }

    // Invoice and Payment Report models
    public class Invoice
    {
        public int Id { get; set; }

        [DisplayName("Invoice Number")]
        public string InvoiceNumber { get; set; }

        [DisplayName("Employee Name")]
        public string EmployeeName { get; set; }

        public int EmployeeId { get; set; }

        [DisplayName("Period")]
        public string Period { get; set; }

        [DisplayName("Total Hours")]
        public decimal TotalHours { get; set; }

        [DisplayName("Hourly Rate")]
        public decimal HourlyRate { get; set; }

        [DisplayName("Total Amount")]
        public decimal TotalAmount { get; set; }

        [DisplayName("Generated Date")]
        public DateTime GeneratedDate { get; set; }

        [DisplayName("Status")]
        public string Status { get; set; } = "Generated";
    }

    public class PaymentReport
    {
        public int Id { get; set; }

        [DisplayName("Report Period")]
        public string ReportPeriod { get; set; }

        [DisplayName("Total Employees")]
        public int TotalEmployees { get; set; }

        [DisplayName("Total Hours")]
        public decimal TotalHours { get; set; }

        [DisplayName("Total Amount")]
        public decimal TotalAmount { get; set; }

        [DisplayName("Generated Date")]
        public DateTime GeneratedDate { get; set; }

        [DisplayName("Report Type")]
        public string ReportType { get; set; }
    }
    // Add this to the existing Models/Employee.cs file, at the bottom
    public class PaymentReportSummary
    {
        public int TotalApprovedClaims { get; set; }
        public decimal TotalHours { get; set; }
        public decimal TotalEarnings { get; set; }
        public decimal AverageHourlyRate { get; set; }
        public List<Employee> ApprovedEmployees { get; set; } = new List<Employee>();
        public DateTime ReportDate { get; set; } = DateTime.Now;
    }
}