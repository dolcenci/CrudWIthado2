﻿using Microsoft.AspNetCore.Mvc;
using Moq;
using CRUDWithADONet.Controllers;
using CRUDWithADONet.DAL;
using CRUDWithADONet.Models;
using System.Collections.Generic;
using Xunit;

namespace CRUDWithADONet.Tests.Controllers
{
    public class EmployeeControllerTests
    {
        private readonly Mock<Employee_DAL> _mockDal;
        private readonly EmployeeController _controller;

        public EmployeeControllerTests()
        {
            _mockDal = new Mock<Employee_DAL>();
            _controller = new EmployeeController(_mockDal.Object);
        }

        [Fact]
        public void Index_ReturnsViewWithEmployees()
        {
            // Arrange
            var employees = new List<Employee>
            {
                new Employee { ID = 1, FirstName = "John", LastName = "Doe", Email = "john@example.com", Salary = 50000 },
                new Employee { ID = 2, FirstName = "Jane", LastName = "Smith", Email = "jane@example.com", Salary = 60000 }
            };
            _mockDal.Setup(dal => dal.GetAll()).Returns(employees);

            // Act
            var result = _controller.Index();

            // Assert
            var viewResult = Assert.IsType<ViewResult>(result);
            var model = Assert.IsAssignableFrom<List<Employee>>(viewResult.Model);
            Assert.Equal(2, model.Count);
        }

        [Fact]
        public void Index_ReturnsViewWithEmptyList_WhenNoEmployees()
        {
            // Arrange
            var employees = new List<Employee>();
            _mockDal.Setup(dal => dal.GetAll()).Returns(employees);

            // Act
            var result = _controller.Index();

            // Assert
            var viewResult = Assert.IsType<ViewResult>(result);
            var model = Assert.IsAssignableFrom<List<Employee>>(viewResult.Model);
            Assert.Empty(model);
        }

        [Fact]
        public void Create_Get_ReturnsView()
        {
            // Act
            var result = _controller.Create();

            // Assert
            Assert.IsType<ViewResult>(result);
        }

        [Fact]
        public void Create_Post_WithValidModel_RedirectsToIndex()
        {
            // Arrange
            var employee = new Employee
            {
                FirstName = "Test",
                LastName = "User",
                Email = "test@example.com",
                DateOfBirth = new System.DateTime(1990, 1, 1),
                Salary = 50000
            };
            _mockDal.Setup(dal => dal.Create(employee)).Returns(true);

            // Act
            var result = _controller.Create(employee);

            // Assert
            var redirectResult = Assert.IsType<RedirectToActionResult>(result);
            Assert.Equal("Index", redirectResult.ActionName);
        }

        [Fact]
        public void Create_Post_WithInvalidModel_ReturnsView()
        {
            // Arrange
            var employee = new Employee { FirstName = "" }; // Invalid - missing required fields
            _controller.ModelState.AddModelError("FirstName", "Required");

            // Act
            var result = _controller.Create(employee);

            // Assert
            Assert.IsType<ViewResult>(result);
        }

        [Fact]
        public void Edit_Get_WithValidId_ReturnsViewWithEmployee()
        {
            // Arrange
            var employee = new Employee { ID = 1, FirstName = "John", LastName = "Doe" };
            _mockDal.Setup(dal => dal.GetById(1)).Returns(employee);

            // Act
            var result = _controller.Edit(1);

            // Assert
            var viewResult = Assert.IsType<ViewResult>(result);
            var model = Assert.IsType<Employee>(viewResult.Model);
            Assert.Equal(1, model.ID);
        }

        [Fact]
        public void Edit_Get_WithInvalidId_RedirectsToIndex()
        {
            // Arrange
            _mockDal.Setup(dal => dal.GetById(999)).Returns((Employee)null);

            // Act
            var result = _controller.Edit(999);

            // Assert
            Assert.IsType<RedirectToActionResult>(result);
        }

        [Fact]
        public void Edit_Post_WithValidModel_RedirectsToIndex()
        {
            // Arrange
            var employee = new Employee
            {
                ID = 1,
                FirstName = "Updated",
                LastName = "User",
                Email = "updated@example.com",
                DateOfBirth = new System.DateTime(1990, 1, 1),
                Salary = 55000
            };
            _mockDal.Setup(dal => dal.Update(employee)).Returns(true);

            // Act
            var result = _controller.Edit(employee);

            // Assert
            var redirectResult = Assert.IsType<RedirectToActionResult>(result);
            Assert.Equal("Index", redirectResult.ActionName);
        }

        [Fact]
        public void Delete_Post_WithValidId_RedirectsToIndex()
        {
            // Arrange
            _mockDal.Setup(dal => dal.Delete(1)).Returns(true);

            // Act
            var result = _controller.DeleteConfirmed(1);

            // Assert
            var redirectResult = Assert.IsType<RedirectToActionResult>(result);
            Assert.Equal("Index", redirectResult.ActionName);
        }
    }
}