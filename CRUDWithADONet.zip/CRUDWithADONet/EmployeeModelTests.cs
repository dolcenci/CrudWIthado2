﻿using CRUDWithADONet.Models;
using System.ComponentModel.DataAnnotations;
using Xunit;

namespace CRUDWithADONet.Tests.Models
{
    public class EmployeeModelTests
    {
        [Fact]
        public void Employee_FullName_ReturnsCorrectFormat()
        {
            // Arrange
            var employee = new Employee
            {
                FirstName = "John",
                LastName = "Doe"
            };

            // Act
            var fullName = employee.FullName;

            // Assert
            Assert.Equal("John Doe", fullName);
        }

        [Fact]
        public void Employee_RequiredFields_Validation()
        {
            // Arrange
            var employee = new Employee
            {
                FirstName = "", // Invalid - empty
                LastName = "Doe",
                Email = "test@example.com",
                DateOfBirth = new System.DateTime(1990, 1, 1),
                Salary = 50000
            };
            var validationContext = new ValidationContext(employee);
            var validationResults = new List<ValidationResult>();

            // Act
            var isValid = Validator.TryValidateObject(employee, validationContext, validationResults, true);

            // Assert
            Assert.False(isValid);
            Assert.Contains(validationResults, vr => vr.MemberNames.Contains("FirstName"));
        }

        [Fact]
        public void Employee_ValidModel_PassesValidation()
        {
            // Arrange
            var employee = new Employee
            {
                FirstName = "John",
                LastName = "Doe",
                Email = "john@example.com",
                DateOfBirth = new System.DateTime(1990, 1, 1),
                Salary = 50000
            };
            var validationContext = new ValidationContext(employee);
            var validationResults = new List<ValidationResult>();

            // Act
            var isValid = Validator.TryValidateObject(employee, validationContext, validationResults, true);

            // Assert
            Assert.True(isValid);
        }

        [Theory]
        [InlineData("", "Doe", "test@example.com")] // Empty first name
        [InlineData("John", "", "test@example.com")] // Empty last name
        [InlineData("John", "Doe", "")] // Empty email
        public void Employee_InvalidData_FailsValidation(string firstName, string lastName, string email)
        {
            // Arrange
            var employee = new Employee
            {
                FirstName = firstName,
                LastName = lastName,
                Email = email,
                DateOfBirth = new System.DateTime(1990, 1, 1),
                Salary = 50000
            };
            var validationContext = new ValidationContext(employee);
            var validationResults = new List<ValidationResult>();

            // Act
            var isValid = Validator.TryValidateObject(employee, validationContext, validationResults, true);

            // Assert
            Assert.False(isValid);
        }
    }
}