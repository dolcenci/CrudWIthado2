﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using CRUDWithADONet.Models;
using System.Collections.Generic;
using Xunit;

namespace CRUDWithADONet.Tests.Views
{
    public class ViewTests
    {
        [Fact]
        public void Employee_IndexView_DisplaysEmployeeData()
        {
            // Arrange
            var employees = new List<Employee>
            {
                new Employee { ID = 1, FirstName = "John", LastName = "Doe", Email = "john@example.com", Salary = 50000 },
                new Employee { ID = 2, FirstName = "Jane", LastName = "Smith", Email = "jane@example.com", Salary = 60000 }
            };

            // This test verifies that the view model can handle the data
            Assert.NotNull(employees);
            Assert.Equal(2, employees.Count);
            Assert.Equal("John Doe", employees[0].FullName);
        }

        [Fact]
        public void Employee_CreateView_ModelHasRequiredProperties()
        {
            // Arrange
            var employee = new Employee();

            // Act & Assert - Verify model has all required properties
            Assert.NotNull(employee);
            Assert.True(employee.GetType().GetProperty("FirstName") != null);
            Assert.True(employee.GetType().GetProperty("LastName") != null);
            Assert.True(employee.GetType().GetProperty("Email") != null);
            Assert.True(employee.GetType().GetProperty("DateOfBirth") != null);
            Assert.True(employee.GetType().GetProperty("Salary") != null);
        }
    }
}